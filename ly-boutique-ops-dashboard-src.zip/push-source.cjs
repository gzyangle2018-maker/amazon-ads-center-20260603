// Quick upload of changed source files
const https = require('https');
const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const OWNER = 'gzyangle2018-maker';
const REPO = 'ly-boutique-ops-dashboard-20260602-v1234';

function ghApi(method, endpoint, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.github.com${endpoint}`);
    const options = {
      hostname: url.hostname, path: url.pathname + url.search, method,
      headers: { 'Authorization': `token ${GITHUB_TOKEN}`, 'Accept': 'application/vnd.github+json', 'User-Agent': 'deploy', 'Content-Type': body ? 'application/json' : undefined },
    };
    Object.keys(options.headers).forEach(k => { if (!options.headers[k]) delete options.headers[k]; });
    const req = https.request(options, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch { resolve(d); } });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function uploadFile(rel) {
  const full = path.join(__dirname, '..', rel);
  if (!fs.existsSync(full)) return;
  const content = fs.readFileSync(full).toString('base64');
  try {
    // Check if file exists
    const existing = await ghApi('GET', `/repos/${OWNER}/${REPO}/contents/${rel}`).catch(() => null);
    await ghApi('PUT', `/repos/${OWNER}/${REPO}/contents/${rel}`, {
      message: `Update ${rel} — editable API keys + Dataler integration`,
      content,
      ...(existing?.sha ? { sha: existing.sha } : {}),
    });
    console.log(`  ✅ ${rel}`);
  } catch (e) {
    console.log(`  ⚠️  ${rel}: ${e.message}`);
  }
}

async function main() {
  const files = [
    'src/store/index.ts',
    'src/routes/ModelConfig.tsx',
    'src/routes/AgentHub.tsx',
    'src/components/common/AgentCard.tsx',
    'src/components/common/DataTable.tsx',
  ];
  for (const f of files) await uploadFile(f);
  console.log('\n✅ Source updates pushed');
}

main().catch(e => { console.error(e.message); process.exit(1); });
