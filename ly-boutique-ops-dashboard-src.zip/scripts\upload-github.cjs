// scripts/upload-github.cjs
// Upload new files (workers/, scripts/, wrangler.toml) to GitHub
const https = require('https');
const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const OWNER = 'gzyangle2018-maker';
const REPO = 'ly-boutique-ops-dashboard-20260602-v1234';

function ghApi(method, endpoint, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.github.com${endpoint}`);
    const options = {
      hostname: url.hostname, path: url.pathname + url.search, method,
      headers: { 'Authorization': `token ${GITHUB_TOKEN}`, 'Accept': 'application/vnd.github+json', 'User-Agent': 'deploy', 'Content-Type': body ? 'application/json' : undefined },
    };
    Object.keys(options.headers).forEach(k => { if (!options.headers[k]) delete options.headers[k]; });
    const req = https.request(options, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve(JSON.parse(d)); } catch { resolve(d); }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function main() {
  const newFiles = [
    'wrangler.toml',
    'workers/api.js',
    'workers/schema.sql',
    'scripts/deploy-all.cjs',
    'scripts/cf-deploy.cjs',
    'scripts/upload-github.cjs',
  ];

  for (const rel of newFiles) {
    const full = path.join(__dirname, '..', rel);
    if (!fs.existsSync(full)) { console.log(`  ⚠️  跳过(不存在): ${rel}`); continue; }
    const content = fs.readFileSync(full).toString('base64');
    try {
      await ghApi('PUT', `/repos/${OWNER}/${REPO}/contents/${rel}`, {
        message: `Add ${rel}`,
        content,
      });
      console.log(`  ✅ ${rel}`);
    } catch (e) {
      console.log(`  ⚠️  ${rel}: ${e.message}`);
    }
  }
  console.log('\n✅ GitHub 更新完成');
}

main().catch(e => { console.error(e.message); process.exit(1); });
