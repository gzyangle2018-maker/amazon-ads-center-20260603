// scripts/deploy-pages-v2.cjs
const https = require('https');
const fs = require('fs');
const path = require('path');

const TOKEN = 'cfut_AqjQWN2DVymDqkhoAXWBPddtGsWpYpNBVDYO3BRk2a0ad7d8';
const ACCOUNT = 'ebba6be2d4369da1443736cb2f66b182';
const PROJECT = 'ly-boutique-ops-dashboard-20260602-v1234';

function call(method, path, body = null, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.cloudflare.com/client/v4${path}`);
    const opts = {
      hostname: url.hostname, path: url.pathname + url.search, method,
      headers: { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json', ...extraHeaders },
    };
    const req = https.request(opts, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, ...JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, raw: d }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function main() {
  const distDir = path.join(__dirname, '..', 'dist');
  const files = fs.readdirSync(distDir).map(f => path.join(distDir, f));
  console.log(`📤 上传 ${files.length} 个文件...\n`);

  // Try Cloudflare Pages direct upload via the newer "assets" endpoint
  // POST /accounts/:id/pages/projects/:project/assets
  console.log('Trying assets upload...');
  for (const file of files) {
    const name = path.basename(file);
    const content = fs.readFileSync(file);
    const r1 = await call('POST',
      `/accounts/${ACCOUNT}/pages/projects/${PROJECT}/assets`,
      null,
      {}
    );
    console.log(`  ${name}: ${r1.status} ${JSON.stringify(r1).slice(0,300)}`);
  }
}

main().catch(e => console.error(e.message));
