// scripts/deploy-all.js
// 一键部署：GitHub 仓库 + Cloudflare Pages + Workers + D1 + R2
//
// 用法: node scripts/deploy-all.js
// 需要: node --version (v24 测试通过)
//
// 环境变量（从命令行参数或硬编码读取）:
//   GITHUB_TOKEN  = ghp_xxx
//   CF_API_TOKEN  = cfut_xxx

const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ─── CONFIG ──────────────────────────────────────────────
const GITHUB_TOKEN = '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';
const CF_API_TOKEN = 'cfut_AqjQWN2DVymDqkhoAXWBPddtGsWpYpNBVDYO3BRk2a0ad7d8';

const GITHUB_OWNER = 'gzyangle2018-maker';
const DATE_STR = new Date().toISOString().slice(0, 10).replace(/-/g, '');
const REPO_NAME = `ly-boutique-ops-dashboard-${DATE_STR}-v1234`;
const CF_ACCOUNT_ID = ''; // 需要从 Cloudflare API 获取

const PROJECT_ROOT = path.resolve(__dirname, '..');
// ──────────────────────────────────────────────────────────

function githubApi(method, endpoint, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.github.com${endpoint}`);
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method,
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`,
        'Accept': 'application/vnd.github+json',
        'User-Agent': 'deploy-script',
        'Content-Type': body ? 'application/json' : undefined,
      },
    };
    // filter out undefined headers
    Object.keys(options.headers).forEach(k => {
      if (options.headers[k] === undefined) delete options.headers[k];
    });

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (res.statusCode >= 400) {
            reject(new Error(`GitHub API ${method} ${endpoint} → ${res.statusCode}: ${json.message || data}`));
          } else {
            resolve(json);
          }
        } catch {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

function cfApi(method, endpoint, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.cloudflare.com/client/v4${endpoint}`);
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method,
      headers: {
        'Authorization': `Bearer ${CF_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (!json.success && res.statusCode >= 400) {
            reject(new Error(`CF API ${method} ${endpoint} → ${res.statusCode}: ${JSON.stringify(json.errors)}`));
          } else {
            resolve(json);
          }
        } catch {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

// Walk directory recursively
function walkDir(dir, base = dir) {
  const results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...walkDir(full, base));
    } else {
      const rel = path.relative(base, full).replace(/\\/g, '/');
      results.push({ rel, full });
    }
  }
  return results;
}

async function main() {
  console.log('╔══════════════════════════════════════════╗');
  console.log('║  LY Boutique Ops Dashboard — Deploy All  ║');
  console.log('╚══════════════════════════════════════════╝');
  console.log(`\n📦 目标仓库: ${GITHUB_OWNER}/${REPO_NAME}`);
  console.log('');

  // ── Step 1: Create GitHub repo ──
  console.log('📁 Step 1/6: 创建 GitHub 仓库...');
  let repo;
  try {
    repo = await githubApi('POST', `/user/repos`, {
      name: REPO_NAME,
      description: 'LY 小精品数据总控分析官 — 亚马逊小精品运营决策中台',
      private: false,
      auto_init: true,
    });
    console.log(`   ✅ 仓库已创建: ${repo.html_url}`);
  } catch (e) {
    if (e.message.includes('already exists') || e.message.includes('422')) {
      console.log('   ⚠️  仓库已存在，使用现有仓库');
      repo = await githubApi('GET', `/repos/${GITHUB_OWNER}/${REPO_NAME}`);
      console.log(`   ✅ 使用已有仓库: ${repo.html_url}`);
    } else {
      throw e;
    }
  }

  // ── Step 2: Upload all files ──
  console.log('\n📤 Step 2/6: 上传源代码文件...');
  const files = walkDir(PROJECT_ROOT).filter(f => {
    // Skip node_modules, .git, dist, scripts dir itself
    return !f.rel.startsWith('node_modules/') &&
           !f.rel.startsWith('.git/') &&
           !f.rel.startsWith('dist/') &&
           !f.rel.startsWith('scripts/');
  });

  let uploaded = 0;
  for (const file of files) {
    const content = fs.readFileSync(file.full);
    const contentBase64 = content.toString('base64');

    try {
      await githubApi('PUT', `/repos/${GITHUB_OWNER}/${REPO_NAME}/contents/${file.rel}`, {
        message: `Add ${file.rel}`,
        content: contentBase64,
      });
      uploaded++;
      if (uploaded % 10 === 0) process.stdout.write(`   ${uploaded}/${files.length}...\r`);
    } catch (e) {
      // File might already exist, try updating
      try {
        const existing = await githubApi('GET', `/repos/${GITHUB_OWNER}/${REPO_NAME}/contents/${file.rel}`);
        await githubApi('PUT', `/repos/${GITHUB_OWNER}/${REPO_NAME}/contents/${file.rel}`, {
          message: `Update ${file.rel}`,
          content: contentBase64,
          sha: existing.sha,
        });
        uploaded++;
      } catch (e2) {
        console.log(`   ⚠️  跳过 ${file.rel}: ${e2.message}`);
      }
    }
  }
  console.log(`   ✅ 已上传 ${uploaded}/${files.length} 个文件`);

  // ── Step 3: Get Cloudflare Account ID ──
  console.log('\n☁️  Step 3/6: 获取 Cloudflare 账户信息...');
  const accounts = await cfApi('GET', '/accounts');
  const accountId = accounts.result?.[0]?.id;
  if (!accountId) throw new Error('未找到 Cloudflare 账户');
  console.log(`   ✅ Account ID: ${accountId}`);

  // ── Step 4: Create Cloudflare Pages project ──
  console.log('\n📄 Step 4/6: 创建 Cloudflare Pages 项目...');
  const pagesProjectName = REPO_NAME;
  let pagesProject;
  try {
    pagesProject = await cfApi('POST', `/accounts/${accountId}/pages/projects`, {
      name: pagesProjectName,
      production_branch: 'main',
      build_config: {
        build_command: 'cd ly-boutique-ops-dashboard && npm install && npm run build',
        destination_dir: 'ly-boutique-ops-dashboard/dist',
        root_dir: '/',
      },
    });
    console.log(`   ✅ Pages 项目已创建: ${pagesProject.result.name}.pages.dev`);
  } catch (e) {
    if (e.message.includes('already exists') || e.message.includes('duplicate')) {
      console.log('   ⚠️  项目已存在，获取现有项目...');
      const list = await cfApi('GET', `/accounts/${accountId}/pages/projects?name=${pagesProjectName}`);
      pagesProject = { result: list.result?.[0] };
      if (!pagesProject.result) throw new Error('无法找到已有项目');
      console.log(`   ✅ 使用已有项目: ${pagesProject.result.name}`);
    } else {
      throw e;
    }
  }

  // ── Step 5: Create D1 Database ──
  console.log('\n🗄️  Step 5/6: 创建 Cloudflare D1 数据库...');
  const d1Name = `${REPO_NAME}-db`;
  let d1Db;
  try {
    d1Db = await cfApi('POST', `/accounts/${accountId}/d1/database`, {
      name: d1Name,
    });
    console.log(`   ✅ D1 数据库已创建: ${d1Db.result.uuid}`);
  } catch (e) {
    console.log(`   ⚠️  D1 创建跳过: ${e.message}`);
  }

  // ── Step 6: Create R2 Bucket ──
  console.log('\n📦 Step 6/6: 创建 Cloudflare R2 存储桶...');
  const r2Name = `${REPO_NAME}-files`;
  try {
    await cfApi('POST', `/accounts/${accountId}/r2/buckets`, {
      name: r2Name,
    });
    console.log(`   ✅ R2 存储桶已创建: ${r2Name}`);
  } catch (e) {
    console.log(`   ⚠️  R2 创建跳过: ${e.message}`);
  }

  // ── Summary ──
  console.log('\n═══════════════════════════════════════');
  console.log('  🎉 部署完成！');
  console.log('═══════════════════════════════════════');
  console.log(`  GitHub:    https://github.com/${GITHUB_OWNER}/${REPO_NAME}`);
  console.log(`  Pages:     https://${pagesProjectName}.pages.dev`);
  console.log(`  Dashboard: https://dash.cloudflare.com/${accountId}/pages`);
  console.log('═══════════════════════════════════════\n');
}

main().catch(e => {
  console.error('\n❌ 部署失败:', e.message);
  process.exit(1);
});
