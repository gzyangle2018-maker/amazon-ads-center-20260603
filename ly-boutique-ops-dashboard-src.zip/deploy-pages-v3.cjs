// scripts/deploy-pages-v3.cjs
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const TOKEN = 'cfut_AqjQWN2DVymDqkhoAXWBPddtGsWpYpNBVDYO3BRk2a0ad7d8';
const ACCOUNT = 'ebba6be2d4369da1443736cb2f66b182';
const PROJECT = 'ly-boutique-ops-dashboard-20260602-v1234';

function cfApi(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.cloudflare.com/client/v4${path}`);
    const opts = {
      hostname: url.hostname, path: url.pathname + url.search, method,
      headers: { 'Authorization': `Bearer ${TOKEN}`, ...headers },
    };
    if (body && typeof body === 'object' && !Buffer.isBuffer(body)) {
      opts.headers['Content-Type'] = 'application/json';
    }
    const req = https.request(opts, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve(JSON.parse(d)); } catch { resolve({ raw: d, status: res.statusCode }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(typeof body === 'string' ? body : Buffer.isBuffer(body) ? body : JSON.stringify(body));
    req.end();
  });
}

// Upload a single file to a signed URL
function uploadToSignedUrl(signedUrl, filePath) {
  return new Promise((resolve, reject) => {
    const url = new URL(signedUrl);
    const content = fs.readFileSync(filePath);
    const req = https.request({
      hostname: url.hostname, path: url.pathname + url.search,
      method: 'PUT',
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Length': content.length,
      },
    }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode }));
    });
    req.on('error', reject);
    req.write(content);
    req.end();
  });
}

async function deployViaGitIntegration() {
  console.log('🔗 尝试通过 Git 集成触发部署...\n');

  // Cloudflare Pages can deploy from GitHub via the deployment hook
  // POST /accounts/:id/pages/projects/:project/deployments
  const r = await cfApi('POST',
    `/accounts/${ACCOUNT}/pages/projects/${PROJECT}/deployments`,
    { branch: 'main' }
  );
  console.log(JSON.stringify(r, null, 2));

  if (r.success && r.result) {
    console.log(`\n✅ 部署已触发！`);
    console.log(`   ID: ${r.result.id}`);
    console.log(`   URL: ${r.result.url || 'pending...'}`);
    return r.result;
  }
  return null;
}

async function deployViaDirectUpload() {
  console.log('📤 使用 Direct Upload 部署...\n');

  const distDir = path.join(__dirname, '..', 'dist');
  const assetFiles = [];

  function walk(dir, base) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full, base);
      else assetFiles.push({ rel: path.relative(base, full).replace(/\\/g, '/'), full });
    }
  }
  walk(distDir, distDir);

  console.log(`   文件数: ${assetFiles.length}`);

  // Step 1: Get upload tokens for each file
  const assetManifest = {};
  for (const f of assetFiles) {
    const hash = crypto.createHash('sha256').update(fs.readFileSync(f.full)).digest('hex');
    const r = await cfApi('POST',
      `/accounts/${ACCOUNT}/pages/projects/${PROJECT}/assets`,
      { key: f.rel, sha256: hash, content_type: f.rel.endsWith('.html') ? 'text/html' : f.rel.endsWith('.css') ? 'text/css' : f.rel.endsWith('.js') ? 'application/javascript' : 'application/octet-stream' }
    );
    console.log(`   Upload token for ${f.rel}: ${r.success ? 'OK' : JSON.stringify(r.errors)}`);
    if (r.success) {
      await uploadToSignedUrl(r.result.upload_url, f.full);
      assetManifest[f.rel] = r.result.id;
    }
  }

  console.log(`\n   已上传 ${Object.keys(assetManifest).length} 个资源`);

  // Step 2: Create deployment with manifest
  const deploy = await cfApi('POST',
    `/accounts/${ACCOUNT}/pages/projects/${PROJECT}/deployments`,
    { manifest: assetManifest }
  );
  console.log(`   部署: ${JSON.stringify(deploy, null, 2)}`);

  return deploy;
}

async function main() {
  // Try Git-triggered deployment first
  let result = await deployViaGitIntegration();

  // Fall back to direct upload if git trigger fails
  if (!result) {
    result = await deployViaDirectUpload();
  }

  console.log(`\n🌐 https://${PROJECT}.pages.dev`);
}

main().catch(e => console.error('❌', e.message));
