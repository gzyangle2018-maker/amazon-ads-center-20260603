// scripts/deploy-pages.cjs
// Upload dist/ to Cloudflare Pages via Direct Upload API
const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CF_API_TOKEN = 'cfut_AqjQWN2DVymDqkhoAXWBPddtGsWpYpNBVDYO3BRk2a0ad7d8';
const ACCOUNT_ID = 'ebba6be2d4369da1443736cb2f66b182';
const PROJECT_NAME = 'ly-boutique-ops-dashboard-20260602-v1234';

function cfApi(method, endpoint, body = null, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.cloudflare.com/client/v4${endpoint}`);
    const options = {
      hostname: url.hostname, path: url.pathname + url.search, method,
      headers: { 'Authorization': `Bearer ${CF_API_TOKEN}`, ...extraHeaders },
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch { resolve({ raw: data, status: res.statusCode }); }
      });
    });
    req.on('error', reject);
    if (body) { req.write(typeof body === 'string' ? body : JSON.stringify(body)); }
    req.end();
  });
}

function walkDir(dir, base = dir) {
  const results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) results.push(...walkDir(full, base));
    else { const rel = path.relative(base, full).replace(/\\/g, '/'); results.push({ rel, full }); }
  }
  return results;
}

async function main() {
  console.log('📤 部署前端到 Cloudflare Pages...\n');

  const distDir = path.join(__dirname, '..', 'dist');
  if (!fs.existsSync(distDir)) {
    console.log('❌ dist/ 目录不存在，请先运行 npm run build');
    process.exit(1);
  }

  const files = walkDir(distDir);
  console.log(`   📁 dist/ 共 ${files.length} 个文件\n`);

  // Step 1: Get upload URL
  console.log('Step 1: 获取上传凭证...');
  const upload = await cfApi('POST', `/accounts/${ACCOUNT_ID}/pages/projects/${PROJECT_NAME}/deployments/upload-url`);
  if (!upload.success) {
    console.log(`   ❌ ${JSON.stringify(upload.errors)}`);
    process.exit(1);
  }
  const { upload_url, id: deploymentId } = upload.result;
  console.log(`   ✅ Deployment ID: ${deploymentId}\n`);

  // Step 2: Create form data with all files
  console.log('Step 2: 上传静态资源...');
  const boundary = '----FormBoundary' + Math.random().toString(36).slice(2);
  const chunks = [];

  for (const file of files) {
    const content = fs.readFileSync(file.full);
    chunks.push(Buffer.from(`--${boundary}\r\n`));
    chunks.push(Buffer.from(`Content-Disposition: form-data; name="${file.rel}"; filename="${path.basename(file.rel)}"\r\n`));
    chunks.push(Buffer.from(`Content-Type: application/octet-stream\r\n\r\n`));
    chunks.push(content);
    chunks.push(Buffer.from('\r\n'));
  }
  chunks.push(Buffer.from(`--${boundary}--\r\n`));
  const body = Buffer.concat(chunks);

  await new Promise((resolve, reject) => {
    const url = new URL(upload_url);
    const req = https.request({
      hostname: url.hostname, path: url.pathname + url.search, method: 'POST',
      headers: {
        'Authorization': `Bearer ${CF_API_TOKEN}`,
        'Content-Type': `multipart/form-data; boundary=${boundary}`,
        'Content-Length': body.length,
      },
    }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) resolve(d);
        else reject(new Error(`Upload failed: ${res.statusCode} ${d}`));
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });

  console.log('   ✅ 上传完成\n');

  // Step 3: Check deployment status
  console.log('Step 3: 等待部署完成...');
  let attempts = 0;
  while (attempts < 30) {
    await new Promise(r => setTimeout(r, 2000));
    const status = await cfApi('GET', `/accounts/${ACCOUNT_ID}/pages/projects/${PROJECT_NAME}/deployments/${deploymentId}`);
    const stage = status.result?.latest_stage?.name || status.result?.deployment_trigger?.metadata?.status || 'unknown';
    console.log(`   ⏳ ${stage}...`);
    if (stage === 'deploy' || status.result?.latest_stage?.status === 'success') {
      console.log(`\n   ✅ 部署成功！`);
      break;
    }
    if (status.result?.latest_stage?.status === 'failure') {
      console.log(`\n   ❌ 部署失败: ${JSON.stringify(status.result.latest_stage)}`);
      break;
    }
    attempts++;
  }

  console.log(`\n═══════════════════════════════════════════`);
  console.log(`  🎉 前端已上线！`);
  console.log(`  🌐 https://${PROJECT_NAME}.pages.dev`);
  console.log(`═══════════════════════════════════════════\n`);
}

main().catch(e => { console.error('❌', e.message); process.exit(1); });
