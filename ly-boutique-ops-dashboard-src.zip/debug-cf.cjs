// scripts/debug-cf.cjs
const https = require('https');

const TOKEN = 'cfut_AqjQWN2DVymDqkhoAXWBPddtGsWpYpNBVDYO3BRk2a0ad7d8';
const ACCOUNT = 'ebba6be2d4369da1443736cb2f66b182';
const PROJECT = 'ly-boutique-ops-dashboard-20260602-v1234';

function call(method, path) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.cloudflare.com/client/v4${path}`);
    const req = https.request({
      hostname: url.hostname, path: url.pathname + url.search, method,
      headers: { 'Authorization': `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
    }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { console.log(`[${res.statusCode}] ${path}\n${d.slice(0, 1500)}\n---`); resolve(); });
    });
    req.on('error', reject);
    req.end();
  });
}

async function main() {
  console.log('Testing CF APIs:\n');
  await call('GET', `/accounts/${ACCOUNT}/pages/projects`);
  await call('GET', `/accounts/${ACCOUNT}/pages/projects/${PROJECT}`);
}

main();
