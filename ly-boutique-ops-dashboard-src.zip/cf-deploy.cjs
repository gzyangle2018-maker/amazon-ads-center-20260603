// scripts/cf-deploy.cjs
// Cloudflare 部署：Pages + Workers + D1 + R2
// 用法: node scripts/cf-deploy.cjs

const https = require('https');
const fs = require('fs');
const path = require('path');

const CF_API_TOKEN = 'cfut_AqjQWN2DVymDqkhoAXWBPddtGsWpYpNBVDYO3BRk2a0ad7d8';
const ACCOUNT_ID = 'ebba6be2d4369da1443736cb2f66b182';
const PROJECT_NAME = 'ly-boutique-ops-dashboard-20260602-v1234';

function cfApi(method, endpoint, body = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(`https://api.cloudflare.com/client/v4${endpoint}`);
    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method,
      headers: {
        'Authorization': `Bearer ${CF_API_TOKEN}`,
        'Content-Type': 'application/json',
      },
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch { resolve({ raw: data, status: res.statusCode }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

function walkDir(dir, base = dir) {
  const results = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...walkDir(full, base));
    } else {
      const rel = path.relative(base, full).replace(/\\/g, '/');
      results.push({ rel, full });
    }
  }
  return results;
}

async function main() {
  console.log('☁️  Cloudflare 全栈部署\n');

  // ── Step 1: Create Pages Project ──
  console.log('📄 Step 1/5: 创建 Cloudflare Pages 项目...');
  let pagesProject;
  try {
    pagesProject = await cfApi('POST', `/accounts/${ACCOUNT_ID}/pages/projects`, {
      name: PROJECT_NAME,
      production_branch: 'main',
    });
    if (pagesProject.success) {
      console.log(`   ✅ Pages 项目已创建: ${pagesProject.result.name}`);
      console.log(`   🌐 域名: ${pagesProject.result.subdomain}.pages.dev`);
    } else {
      console.log(`   ⚠️  ${JSON.stringify(pagesProject.errors)}`);
    }
  } catch (e) {
    console.log(`   ⚠️  创建失败: ${e.message}`);
    // Try getting existing
    const list = await cfApi('GET', `/accounts/${ACCOUNT_ID}/pages/projects`);
    const existing = (list.result || []).find(p => p.name === PROJECT_NAME);
    if (existing) {
      console.log(`   ✅ 使用已有项目: ${existing.name}`);
      pagesProject = { result: existing };
    }
  }

  // ── Step 2: Direct upload to Pages ──
  console.log('\n📤 Step 2/5: 获取 Pages 上传 URL...');
  try {
    const uploadUrl = await cfApi('POST', `/accounts/${ACCOUNT_ID}/pages/projects/${PROJECT_NAME}/deployments/upload-url`);
    console.log(`   ✅ 上传 URL 已获取`);
    // TODO: upload assets zip
  } catch (e) {
    console.log(`   ⚠️  直接上传跳过: ${e.message}`);
    console.log('   💡 需先在前端构建，目前 npm 在沙箱不可用');
    console.log('   📋 手动: cd ly-boutique-ops-dashboard && npm install && npm run build');
    console.log('   📋 然后用 npx wrangler pages deploy dist/');
  }

  // ── Step 3: Create Workers KV namespace (for API) ──
  console.log('\n⚡ Step 3/5: 创建 Workers 后端 (占位)...');
  const workerScript = `
// LY Boutique Ops Dashboard — Backend API Worker
// 部署后通过 Workers 环境变量配置 API Key

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    };
    if (request.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

    // AI Router endpoint
    if (url.pathname === '/api/ai/run' && request.method === 'POST') {
      const body = await request.json();
      return new Response(JSON.stringify({
        success: true,
        message: 'Backend placeholder. Configure Dataler API key in env vars.',
        received: body,
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Health check
    if (url.pathname === '/api/health') {
      return new Response(JSON.stringify({ status: 'ok', timestamp: new Date().toISOString() }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    return new Response(JSON.stringify({ error: 'Not found' }),
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
};`;

  fs.writeFileSync(path.join(__dirname, '..', 'workers', 'api.js'), workerScript.trim());
  console.log('   ✅ Workers API 代码已生成: workers/api.js');
  console.log('   📋 部署: npx wrangler deploy workers/api.js');

  // ── Step 4: D1 Schema ──
  console.log('\n🗄️  Step 4/5: 创建 D1 数据库...');
  try {
    const d1 = await cfApi('POST', `/accounts/${ACCOUNT_ID}/d1/database`, {
      name: `${PROJECT_NAME}-db`,
    });
    if (d1.success) {
      console.log(`   ✅ D1 数据库已创建: ${d1.result.uuid}`);
      console.log(`   📋 绑定到 Worker: npx wrangler d1 bind ${d1.result.name} --binding-name DB`);
    } else {
      console.log(`   ⚠️  ${JSON.stringify(d1.errors)}`);
    }
  } catch (e) {
    console.log(`   ⚠️  ${e.message}`);
  }

  // ── Step 5: R2 Bucket ──
  console.log('\n📦 Step 5/5: 创建 R2 存储桶...');
  try {
    const r2 = await cfApi('POST', `/accounts/${ACCOUNT_ID}/r2/buckets`, {
      name: `${PROJECT_NAME}-files`,
    });
    if (r2.success) {
      console.log(`   ✅ R2 存储桶已创建: ${r2.result.name}`);
    } else {
      console.log(`   ⚠️  ${JSON.stringify(r2.errors)}`);
    }
  } catch (e) {
    console.log(`   ⚠️  ${e.message}`);
  }

  // ── Summary ──
  console.log('\n═══════════════════════════════════════════');
  console.log('  📋 部署总结');
  console.log('═══════════════════════════════════════════');
  console.log(`  GitHub:  https://github.com/gzyangle2018-maker/${PROJECT_NAME}`);
  console.log(`  Pages:   https://${PROJECT_NAME}.pages.dev`);
  console.log(`  CF Dash: https://dash.cloudflare.com/${ACCOUNT_ID}`);
  console.log('');
  console.log('  本地终端执行以下命令完成部署:');
  console.log('');
  console.log('  # 1. 安装依赖并构建前端');
  console.log(`  cd ly-boutique-ops-dashboard`);
  console.log('  npm install && npm run build');
  console.log('');
  console.log('  # 2. 部署 Pages');
  console.log(`  npx wrangler pages deploy dist --project-name=${PROJECT_NAME}`);
  console.log('');
  console.log('  # 3. 部署 Workers API');
  console.log('  npx wrangler deploy workers/api.js');
  console.log('');
  console.log('  # 4. 绑定 D1 数据库');
  console.log(`  npx wrangler d1 execute ${PROJECT_NAME}-db --file=workers/schema.sql`);
  console.log('═══════════════════════════════════════════\n');
}

main().catch(e => { console.error('❌', e.message); process.exit(1); });
